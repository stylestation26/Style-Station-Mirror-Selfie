Style Station Garba Mirror — Mobile Optimized V1
Upload → choose backdrop → create 9:16 story → download.
All assets are local and optimized for mobile.
